# ETHOS‑7 ∞ — Autonomous Core v1.2

Auto‑dependiente (PWA), memoria persistente, aprendizaje incremental, skills y exportación/importación.
